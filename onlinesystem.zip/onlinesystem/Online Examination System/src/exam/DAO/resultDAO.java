package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exam.model.appearexamModel;
import exam.model.registrationmodel;

public class resultDAO {
	 private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<appearexamModel> getStudentResult(String email_id)
	  {
		  ArrayList <appearexamModel> result=new ArrayList<appearexamModel>();
		  appearexamModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select obt_marks,exam_id,app_date,remarks,status,sub_name from appear_exam where email_id=? group by sub_name"); 
	      stmt.setString(1, email_id);
		  ResultSet rs=stmt.executeQuery();  
		  while(rs.next())
			  {  		   
			  temp=new appearexamModel(rs.getInt(1),rs.getInt(2),rs.getString(3),email_id,rs.getString(4),rs.getString(5),rs.getString(6));	
			  result.add(temp);		  
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return result;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<appearexamModel> getStudentResultIndividual(String email_id, String sub_name)
	  {
		  ArrayList <appearexamModel> result=new ArrayList<appearexamModel>();
		  appearexamModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select obt_marks,exam_id,app_date,remarks,status,sub_name from appear_exam where email_id=? AND sub_name=? "); 
	      stmt.setString(1, email_id);
	      stmt.setString(2, sub_name);
		  ResultSet rs=stmt.executeQuery();  
		  while(rs.next())
			  {  		   
			  temp=new appearexamModel(rs.getInt(1),rs.getInt(2),rs.getString(3),email_id,rs.getString(4),rs.getString(5),rs.getString(6));	
			  result.add(temp);		  
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return result;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
}
