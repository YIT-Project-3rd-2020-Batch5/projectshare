package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exam.model.registrationmodel;

public class editProfileDAO {
	 private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<registrationmodel> getStudentDetail(String email_id)
	  {
		  ArrayList <registrationmodel> student=new ArrayList<registrationmodel>();
		  registrationmodel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select name,clss_no,school_reg_no,mobile_no,security_qn,security_ans,password from registration where email_id=? "); 
	      stmt.setString(1, email_id);
		  ResultSet rs=stmt.executeQuery();  
		  while(rs.next())
			  {  		   
			  temp=new registrationmodel(email_id,rs.getString(1),rs.getInt(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));	
			  student.add(temp); 	
			  System.out.println(rs.getString(6));
			  
			  }  
		     closeConnection();	 
		     return student;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static Boolean modifyStudentDetail(String email_id, registrationmodel r)
	  { 
		  int nor=0;
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("update registration set  name=? ,mobile_no=?,clss_no=?,school_reg_no=?,mobile_no=?,security_qn=?,security_ans=?,email_id=? where email_id=? "); 
	      stmt.setString(8, r.getEmail_id());
	      stmt.setString(1, r.getName());
	      stmt.setString(2, r.getMobile_no());
	      stmt.setInt(3, r.getClss_no());
	      stmt.setInt(4, r.getSchool_reg_no());
	      stmt.setString(5, r.getMobile_no());
	      stmt.setString(6, r.getSecurity_qn());
	      stmt.setString(7, r.getSecurity_ans());
	      stmt.setString(9, email_id);
		 nor=stmt.executeUpdate();
		     closeConnection();	 
		     if(nor>0)
		     {
		    	 return true;
		     }
		     return false;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }  	  
	  }
}
