package exam.model;

public class appearexamModel {
	int app_id=3;
	int obt_marks;
	int exam_id;
	String app_date;
	String email_id;
	String remarks;
	String status;
	String sub_name;
	
	
		public appearexamModel(int app_id, int obt_marks, int exam_id, String app_date, String email_id, String remarks,
			String status, String sub_name) {
		super();
		this.app_id= app_id;
		this.obt_marks = obt_marks;
		this.exam_id = exam_id;
		this.app_date = app_date;
		this.email_id = email_id;
		this.remarks = remarks;
		this.status = status;
		this.sub_name=sub_name;
	}
		public appearexamModel(int obt_marks, int exam_id, String app_date, String email_id, String remarks,
			String status, String sub_name) {
		super();
		this.obt_marks = obt_marks;
		this.exam_id = exam_id;
		this.app_date = app_date;
		this.email_id = email_id;
		this.remarks = remarks;
		this.status = status;
		this.sub_name=sub_name;
		}
		public appearexamModel(int exam_id) {
			this.exam_id = exam_id;
		}
		public appearexamModel() {
			this.app_id= app_id;
		}
		public int getApp_id() {
			return app_id;
		}
		public void setApp_id(int app_id) {
			this.app_id = app_id;
		}
		public String getSub_name() {
			return sub_name;
		}
		public void setSub_name(String sub_name) {
			this.sub_name = sub_name;
		}
		public int getObt_marks() {
		return obt_marks;
	}
	public void setObt_marks(int obt_marks) {
		this.obt_marks = obt_marks;
	}
	public int getExam_id() {
		return exam_id;
	}
	public void setExam_id(int exam_id) {
		this.exam_id = exam_id;
	}
	public String getApp_date() {
		return app_date;
	}
	public void setApp_date(String app_date) {
		this.app_date = app_date;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
		
}

