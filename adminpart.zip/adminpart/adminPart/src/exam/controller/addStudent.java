package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import exam.DAO.selectStudents;
import exam.model.registrationmodel;

@WebServlet("/addStudent")
public class addStudent extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		PrintWriter out=response.getWriter();
		String utype="user";		
		String email_id=request.getParameter("email");
		String name=request.getParameter("uname");
		
		String password=request.getParameter("pass");
		String pass1=request.getParameter("pass1");
		String mobile_no=request.getParameter("mobno");
		int class_no=Integer.parseInt(request.getParameter("classno"));
		String security_qn=request.getParameter("secque");
		String security_ans=request.getParameter("secans");
		int school_reg_no=Integer.parseInt(request.getParameter("rollno"));
		String gender=request.getParameter("gender");
		
		if (password.equals(pass1))
		{
			registrationmodel r1=new registrationmodel(name, gender, email_id, password, mobile_no, class_no, security_qn, security_ans, school_reg_no, utype);
			
			if(selectStudents.createacc(r1)==true)
			{
				System.out.println("updated");
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Inserted Succesfully');");
				out.println("location='studentList';");
				out.println("</script>");
			}
		}else
			{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Password mismatch');");
			out.println("location='addStudAdmin.jsp';");
			out.println("</script>");
			}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
