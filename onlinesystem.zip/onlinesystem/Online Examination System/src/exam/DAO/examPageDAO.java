package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exam.model.examModel;
import exam.model.registrationmodel;

public class examPageDAO {
	 private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<examModel> getExamDetail(int clss_no)
	  {
		  ArrayList <examModel> exam=new ArrayList<examModel>();
		  examModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select exam_id, sub_name, clss_no, no_of_que, time_interval, total_marks, start_date, end_date, exam_date from exam where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			//  System.out.println(rs.getInt(1)+ rs.getString(2)+rs.getString(3)+rs.getString(4)+branch);
			  temp=new examModel(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getInt(6), rs.getString(7), rs.getString(8), rs.getString(9));	
			  exam.add(temp); 		  
			  }  
		     closeConnection();	 
		     return exam;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static int getexamid(String email_id)
	  {
		  int n=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select exam_id from appear_exam where email_id=? "); 
	      stmt.setString(1, email_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  	n=rs.getInt(1);	   
				  
			  }  
		     closeConnection();	 
		     return n;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return 0; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return 0; }  
	  }

}
