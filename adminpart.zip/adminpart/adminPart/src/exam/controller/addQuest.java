package exam.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import exam.DAO.selectQuestions;

import exam.model.*;

@WebServlet("/addQuest")
public class addQuest extends HttpServlet implements Servlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		
		HttpSession adminsess1=request.getSession();
		request.setAttribute("clss_no", adminsess1.getAttribute("clss_no"));
		ArrayList<questionModel> quest= new ArrayList<questionModel>();
		quest=selectQuestions.getQuestId();
		int n=1;
		Boolean flag=false;
		for(questionModel r: quest)
		{
			if(r.getQ_id() == n)
			{
				flag=false;
				n++;
				continue;
			}else{
				flag=true;
				request.setAttribute("id", n);
				System.out.println(r.getQ_id());
				System.out.println(n);
				break;
			}
		}
		
		
		rd= request.getRequestDispatcher("addQuestAdmin.jsp");
		rd.forward(request, response);
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
