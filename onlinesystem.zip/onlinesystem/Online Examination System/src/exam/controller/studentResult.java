package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.indexDAO;
import exam.DAO.mainExamDAO;
import exam.DAO.resultDAO;
import exam.model.appearexamModel;
import exam.model.registrationmodel;

@WebServlet("/studentResult")
public class studentResult extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		HttpSession session1=request.getSession();
		HttpSession session3=request.getSession();
		String sub_name= (String) session3.getAttribute("sub_name");
		int clss_no=(int) session3.getAttribute("clss_no");
		ArrayList<appearexamModel> result;
		int n=mainExamDAO.getQuestionCount(clss_no, sub_name);
		ArrayList<registrationmodel> student;
		String email_id=(String) session1.getAttribute("email_id");
		if(indexDAO.getStudentDetail(email_id)!=null)
		{
		if(resultDAO.getStudentResult(email_id)!=null )
		{
			result=resultDAO.getStudentResult(email_id);
			student=indexDAO.getStudentDetail(email_id);
			request.setAttribute("result", result);
			request.setAttribute("student", student);
			request.setAttribute("tmarks", n);
			rd=request.getRequestDispatcher("studentResult.jsp");
			rd.forward(request, response);
		}
		}
		else
		{
			request.setAttribute("errormsg", "oops!!!!!  No results yet to display");
			rd=request.getRequestDispatcher("examOver.jsp");
			rd.forward(request, response);
		}
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
