package exam.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.forgotpassDAO;

/**
 * Servlet implementation class forgotpass1
 */
@WebServlet("/forgotpass1")
public class forgotpass1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		String secqn=null;
		if(request.getParameter("submit").equals("next")){
			String email_id=request.getParameter("email_id");
			HttpSession session=request.getSession();
			session.removeAttribute("email_id");
			if(session.getAttribute("email_id")==null)
			  session.setAttribute("email_id",email_id);
			 
			if(forgotpassDAO.forgotpass1(email_id)!=null)
			{
				secqn=forgotpassDAO.forgotpass1(email_id);
				request.setAttribute("secqn",secqn);
				rd=request.getRequestDispatcher("forgotpass2.jsp");
				rd.forward(request, response);
		    
		}else{
		request.setAttribute("errormsg", "Invalid email id, Please enter the valid email id");
		rd=request.getRequestDispatcher("forgotpass1.jsp");
		rd.forward(request, response);	
		}
		}
		
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
