package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import exam.model.*;

public class selectStudents {
	 private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<registrationmodel> getStudList(int clss_no)
	  {
		  ArrayList <registrationmodel> studentlist=new ArrayList<registrationmodel>();
		  registrationmodel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select name, gender, email_id, password, mobile_no, clss_no, security_qn, security_ans, school_reg_no, utype from registration where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new registrationmodel( rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6),rs.getString(7), rs.getString(8), rs.getInt(9), rs.getString(10));	
			  studentlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return studentlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	 
	  public static ArrayList<registrationmodel> getStudById(String email_id)
	  {
		  ArrayList <registrationmodel> studlist=new ArrayList<registrationmodel>();
		  registrationmodel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select name, gender, email_id, password, mobile_no, clss_no, security_qn, security_ans, school_reg_no, utype from registration where email_id=? "); 
	      stmt.setString(1, email_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new registrationmodel(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6),rs.getString(7), rs.getString(8), rs.getInt(9), rs.getString(10));	
			  studlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return studlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }
	  }
	  
	  
	  public static Boolean updateStudent(registrationmodel r, String email_id)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("update registration set name=?, gender=?, email_id=?, password=?, mobile_no=?, clss_no=?, security_qn=?, security_ans=?, school_reg_no=?, utype=? where email_id=?"); 
	      stmt.setString(1, r.getName());
	      stmt.setString(2, r.getGender());
	      stmt.setString(3, r.getEmail_id());
	      stmt.setString(4, r.getPassword());
	      stmt.setString(5, r.getMobile_no());
	      stmt.setInt(6, r.getClss_no());
	      stmt.setString(7, r.getSecurity_qn());
	      stmt.setString(8, r.getSecurity_ans());
	      stmt.setInt(9, r.getSchool_reg_no());
	      stmt.setString(10, r.getUtype());
	      stmt.setString(11, email_id);
	      System.out.println(email_id);
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
	  
	  public static Boolean createacc(registrationmodel r)
	  {  
		  try
		  {
		  getConnection();
		  int nor=0;
	      stmt=con.prepareStatement("insert into registration values(?,?,?,?,?,?,?,?,?,?) "); 
	      stmt.setString(1, r.getName());
	      stmt.setString(2, r.getGender());
	      stmt.setString(3, r.getEmail_id());
	      stmt.setString(4, r.getPassword());
	      stmt.setString(5, r.getMobile_no());
	      stmt.setInt(6, r.getClss_no());
	      stmt.setString(7, r.getSecurity_qn());
	      stmt.setString(8, r.getSecurity_ans());
	      stmt.setInt(9, r.getSchool_reg_no());
	      stmt.setString(10, r.getUtype());
	      nor=stmt.executeUpdate();
		     closeConnection();	 
		    if(nor>0)
		    {
		    	return true;
		    }
		    return false;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }  	  
	  }
	  
	  public static Boolean deleteStudent(String email_id)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("delete from registration where email_id=? "); 
	      stmt.setString(1, email_id);
	     
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
}

