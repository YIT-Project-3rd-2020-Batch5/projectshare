package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.indexDAO;
import exam.DAO.mainExamDAO;
import exam.DAO.resultDAO;
import exam.model.appearexamModel;
import exam.model.questionModel;
import exam.model.registrationmodel;

@WebServlet("/mainExam")
public class mainExam extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		HttpSession session3=request.getSession();
		ArrayList<questionModel> question;
		String sub_name=(String) session3.getAttribute("sub_name");
		int clss_no=(int) session3.getAttribute("clss_no");
		if(mainExamDAO.getQuestionForStud(sub_name, clss_no)!=null)
		{
			question=mainExamDAO.getQuestionForStud(sub_name, clss_no);
			HttpSession session1=request.getSession();
			String email_id=(String) session1.getAttribute("email_id");
			request.setAttribute("question", question);
			int n1=0;
			int correctans=0;
			String ans=null;
			int n=mainExamDAO.getQuestionCount(clss_no, sub_name);
			String s=Integer.toString(n);
			request.setAttribute("n", s);
			while(n1>=n){
				ans=request.getParameter("option"+n1);
				System.out.println(ans);
				if(ans!=null){
			for(questionModel r: question)
			{
				
				System.out.println(r.getAns());
				if(ans.equals(r.getAns()))
						{
					  correctans++;
						}
			}
				}
			}
			System.out.println(correctans);
			rd=request.getRequestDispatcher("mainExam.jsp");
			rd.forward(request, response);
			
		}
		else
		{
			rd=request.getRequestDispatcher("indexController");
			rd.forward(request, response);
		}
	
	
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
